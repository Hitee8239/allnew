# ninebrary

# public 폴더 : 클라이언트에서 접근 가능한 정적 파일들을 저장하는 폴더입니다.
# css 폴더 : CSS 파일을 저장하는 폴더입니다.
# img 폴더 : 이미지 파일을 저장하는 폴더입니다.
# js 폴더 : JavaScript 파일을 저장하는 폴더입니다.
# components 폴더 : 페이지별로 필요한 JavaScript 파일을 저장하는 폴더입니다.
# views 폴더 : Express의 View로 사용되는 HTML 파일을 저장하는 폴더입니다.
# routes 폴더 : Express에서 라우팅을 관리하는 파일을 저장하는 폴더입니다.
# app.js 파일 : Express 애플리케이션의 엔트리 포인트입니다.