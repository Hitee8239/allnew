const express = require('express');
const bodyParser = require('body-parser');
const connection = require('./db');
const fs = require('fs');
const csv = require('fast-csv');

// const mysql = require('sync-mysql');
// const env = require('dotenv').config({ path: "../../.env" });

// var connection = new mysql({
//     host: process.env.host,
//     user: process.env.user,
//     password: process.env.password,
//     database: process.env.database
// });

const app = express()

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.get('/', (req, res) => {
    res.render('main')
})

app.post('/search', function (req, res) {
    const title = req.body.title;
    const query = 'SELECT * FROM booktbl WHERE title LIKE ?';
    connection.query(query, [`%${title}%`], function (err, rows) {
        if (err) throw err;
        res.json(rows);
    });
});





module.exports = app;